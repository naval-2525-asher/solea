import React, { useState, useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Menu, X, Search, ArrowRight, ChevronRight, ShoppingBag, ChevronDown } from "lucide-react";
import { products } from "@/lib/products";
import { useCart } from "@/context/CartContext";
import { useSiteSettings } from "@/hooks/useAdminData";
import { useRegion, REGIONS, Region } from "@/context/RegionContext";

 const AnnouncementBar = () => {
  const { data: settings = [] } = useSiteSettings();
  const text =
    settings.find((s: any) => s.key === "announcement_text")?.value ||
    "Shipping may take up to 4 weeks, for more information check out FAQ";

  const chunk = `${text}\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0✦\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0`;
  const repeated = Array(15).fill(chunk).join("");

  return (
    <div
      className="w-full bg-primary text-primary-foreground py-2 z-[200]"
      style={{ overflow: "hidden", position: "relative" }}
    >
      <div
        style={{
          display: "inline-flex",       // inline-flex instead of flex
          flexShrink: 0,
          whiteSpace: "nowrap",
          animation: "marquee 80s linear infinite",
          willChange: "transform",
        }}
      >
        <span
          style={{
            display: "inline-block",
            flexShrink: 0,
            fontFamily: "Georgia, 'Times New Roman', serif",
            fontSize: "10px",
            fontWeight: "bold",
            letterSpacing: "0.15em",
          }}
        >
          {repeated}
        </span>
        <span
          aria-hidden="true"
          style={{
            display: "inline-block",
            flexShrink: 0,
            fontFamily: "Georgia, 'Times New Roman', serif",
            fontSize: "10px",
            fontWeight: "bold",
            letterSpacing: "0.15em",
          }}
        >
          {repeated}
        </span>
      </div>
    </div>
  );
};

const FlagImg = ({ code, size = 20 }: { code: string; size?: number }) => {
  const iso = code === "UK" ? "gb" : code.toLowerCase();
  return (
    <img
      src={`https://flagcdn.com/w40/${iso}.png`}
      width={size}
      height={size * 0.67}
      alt={code}
      style={{ borderRadius: 3, objectFit: "cover", display: "inline-block", flexShrink: 0 }}
    />
  );
};

const RegionSelector: React.FC = () => {
  const { region, setRegion, regionConfig } = useRegion();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((p) => !p)}
        className="flex items-center gap-1.5 bg-white/40 backdrop-blur-sm border-none cursor-pointer px-2.5 py-1.5 rounded-lg hover:bg-white/60 transition-colors font-serif text-xs text-foreground font-bold"
        aria-label="Select region"
      >
        <FlagImg code={regionConfig.code} size={20} />
        <span className="hidden sm:inline">{regionConfig.currency}</span>
        <ChevronDown size={12} className={`transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <div className="absolute left-0 top-full mt-1.5 bg-card border border-border rounded-xl shadow-xl overflow-hidden z-[700] min-w-[180px]">
          {(Object.values(REGIONS) as typeof REGIONS[Region][]).map((r) => (
            <button
              key={r.code}
              onClick={() => { setRegion(r.code); setOpen(false); }}
              className={`w-full flex items-center gap-2.5 px-4 py-3 font-serif text-sm text-left transition-colors border-none cursor-pointer ${
                region === r.code
                  ? "bg-primary/10 text-primary font-bold"
                  : "bg-transparent text-foreground hover:bg-secondary/60"
              }`}
            >
              <FlagImg code={r.code} size={22} />
              <span className="flex-1">{r.label}</span>
              <span className="text-xs text-foreground/50">{r.currency}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

const Navbar: React.FC = () => {
  const { totalItems } = useCart();
  const { formatPrice } = useRegion();
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const searchInputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (searchOpen && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [searchOpen]);

  useEffect(() => {
    setMenuOpen(false);
    setSearchOpen(false);
    setSearchQuery("");
  }, [location.pathname]);

  const filteredProducts = searchQuery.trim()
    ? products.filter((p) => p.name.toLowerCase().startsWith(searchQuery.toLowerCase()))
    : [];

  return (
    <>
      <AnnouncementBar />

      {/* Burger Menu Overlay */}
      {menuOpen && createPortal(
        <div
          className="fixed inset-0 z-[600] bg-black/50"
          onClick={() => setMenuOpen(false)}
        >
          <div
            className="absolute top-0 left-0 h-full w-[240px] shadow-xl"
            style={{ backgroundColor: "hsl(var(--solea-pink))" }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-5 border-b border-foreground/20">
              <p className="font-serif font-black text-2xl text-foreground">soléa</p>
              <button
                onClick={() => setMenuOpen(false)}
                className="bg-transparent border-none cursor-pointer text-foreground"
              >
                <X size={22} />
              </button>
            </div>
            <nav className="flex flex-col p-4 gap-1">
              <Link
                to="/"
                className="font-serif text-sm text-foreground no-underline py-3 px-4 rounded-lg hover:bg-white/20 transition-colors flex items-center justify-between"
                onClick={() => setMenuOpen(false)}
              >
                Home <ChevronRight size={16} />
              </Link>
              <Link
                to="/sale"
                className="font-serif text-sm no-underline py-3 px-4 rounded-lg hover:bg-red-100/40 transition-colors flex items-center justify-between"
                style={{ color: "#dc2626", fontWeight: 900 }}
                onClick={() => setMenuOpen(false)}
              >
                SALE 🏷️ <ChevronRight size={16} />
              </Link>
              <Link
                to="/shop"
                className="font-serif text-sm text-foreground no-underline py-3 px-4 rounded-lg hover:bg-white/20 transition-colors flex items-center justify-between"
                onClick={() => setMenuOpen(false)}
              >
                Tanks & Tees <ChevronRight size={16} />
              </Link>
              <Link
                to="/accessories"
                className="font-serif text-sm text-foreground no-underline py-3 px-4 rounded-lg hover:bg-white/20 transition-colors flex items-center justify-between"
                onClick={() => setMenuOpen(false)}
              >
                Accessories <ChevronRight size={16} />
              </Link>
              <Link
                to="/limited-edition"
                className="font-serif text-sm text-foreground no-underline py-3 px-4 rounded-lg hover:bg-white/20 transition-colors flex items-center justify-between"
                onClick={() => setMenuOpen(false)}
              >
                Limited Edition <ChevronRight size={16} />
              </Link>
              <Link
                to="/faq"
                className="font-serif text-sm text-foreground no-underline py-3 px-4 rounded-lg hover:bg-white/20 transition-colors flex items-center justify-between"
                onClick={() => setMenuOpen(false)}
              >
                FAQ <ChevronRight size={16} />
              </Link>
            </nav>
          </div>
        </div>,
        document.body
      )}

      {/* Main Navbar */}
      <nav
        className="sticky top-0 z-[500] flex justify-between items-center px-6 pt-3 pb-3 border-b-2 border-solea-rose/30"
        style={{
          background: "repeating-linear-gradient(to right, hsl(var(--solea-pink)), hsl(var(--solea-pink)) 40px, hsl(var(--solea-beige)) 40px, hsl(var(--solea-beige)) 80px)",
        }}
      >
        <div className="flex items-center gap-2">
          <button
            onClick={() => setMenuOpen(true)}
            className="bg-white/40 backdrop-blur-sm border-none cursor-pointer p-2 text-foreground rounded-lg hover:bg-white/60 transition-colors"
          >
            <Menu size={24} />
          </button>
          <RegionSelector />
        </div>

        <Link to="/" className="absolute left-1/2 -translate-x-1/2 no-underline text-center">
          <p className="text-foreground font-serif font-black text-4xl m-0 mt-2 cursor-pointer leading-none">
            soléa
          </p>
          <p className="text-foreground font-serif text-[10px] tracking-[0.3em] m-0 mt-1.5">
            Art &nbsp;You &nbsp;Can &nbsp;Wear
          </p>
        </Link>

        <div className="flex gap-2 items-center">
          <button
            onClick={() => setSearchOpen((prev) => !prev)}
            className="bg-transparent border-none cursor-pointer p-1 text-foreground"
          >
            <Search size={22} />
          </button>
          <Link to="/cart" className="relative p-1 text-foreground">
            <ShoppingBag size={22} />
            <span className="absolute -top-1.5 -right-1.5 bg-destructive text-white text-[10px] font-bold w-[18px] h-[18px] rounded-full flex items-center justify-center font-serif">
              {totalItems}
            </span>
          </Link>
        </div>
      </nav>

      {/* Search Panel */}
      {searchOpen && createPortal(
        <div
          className="fixed inset-0 z-[600] bg-black/50"
          onClick={() => { setSearchOpen(false); setSearchQuery(""); }}
        >
          <div
            className="absolute top-0 right-0 h-full w-[280px] shadow-xl p-5"
            style={{ backgroundColor: "hsl(var(--solea-pink))" }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <p className="font-serif font-black text-lg text-foreground">Search</p>
              <button
                onClick={() => { setSearchOpen(false); setSearchQuery(""); }}
                className="bg-transparent border-none cursor-pointer text-foreground"
              >
                <X size={22} />
              </button>
            </div>
            <div className="flex items-center gap-2 border-b border-foreground/20 pb-2 mb-4">
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search products..."
                className="flex-1 bg-transparent border-none outline-none font-serif text-sm text-foreground placeholder:text-foreground/50"
                onKeyDown={(e) => {
                  if (e.key === "Escape") {
                    setSearchOpen(false);
                    setSearchQuery("");
                  }
                }}
              />
              <button
                onClick={() => {
                  if (filteredProducts.length === 1) {
                    navigate(`/product/${filteredProducts[0].id}`);
                    setSearchOpen(false);
                    setSearchQuery("");
                  }
                }}
                className="bg-transparent border-none cursor-pointer p-1 text-foreground"
              >
                <ArrowRight size={18} />
              </button>
            </div>
            {searchQuery.trim() && (
              <div className="flex flex-col gap-1">
                {filteredProducts.length > 0 ? (
                  filteredProducts.map((product) => (
                    <Link
                      key={product.id}
                      to={`/product/${product.id}`}
                      className="font-serif text-sm text-foreground no-underline py-2 px-3 rounded-lg hover:bg-white/20 transition-colors flex items-center gap-3"
                      onClick={() => { setSearchOpen(false); setSearchQuery(""); }}
                    >
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-8 h-8 rounded object-cover flex-shrink-0"
                        onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }}
                      />
                      <span className="flex-1">{product.name}</span>
                      <span className="text-xs opacity-60">{formatPrice(product.price, product.price_gbp)}</span>
                    </Link>
                  ))
                ) : (
                  <p className="font-serif text-sm text-destructive py-2 px-3">No results found</p>
                )}
              </div>
            )}
          </div>
        </div>,
        document.body
      )}
    </>
  );
};

export default Navbar;