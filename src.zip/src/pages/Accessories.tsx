import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { useProducts, useSaleProducts } from "@/hooks/useAdminData";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import FilterSortBar, { ViewMode } from "@/components/FilterSortBar";
import { useFilterSort } from "@/hooks/useFilterSort";
import { useRegion } from "@/context/RegionContext";

// ─── Static list REMOVED — accessories now come entirely from Supabase ────────
// Any accessory you add in the admin panel will appear here automatically.

const isOutOfStock = (product: any) =>
  product.stock_status === "out_of_stock" || product.stock_status === "Out of Stock";

const isLowStock = (product: any) => product.stock_status === "low_stock";

const calcDiscount = (original: number, sale: number) =>
  Math.round(((original - sale) / original) * 100);

const getGridStyle = (viewMode: ViewMode): React.CSSProperties => {
  if (viewMode === "single") return { display: "grid", gridTemplateColumns: "1fr", gap: "16px" };
  if (viewMode === "double") return { display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "16px" };
  return { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "16px" };
};

const ProductCard = ({
  product,
  viewMode = "triple",
  salePrice,
  salePriceGbp,
}: {
  product: any;
  viewMode?: ViewMode;
  salePrice?: number;
  salePriceGbp?: number;
}) => {
  const oos       = isOutOfStock(product);
  const imgHeight = viewMode === "single" ? "600px" : viewMode === "double" ? "400px" : "340px";
  const discount  = salePrice ? calcDiscount(product.price, salePrice) : null;
  const { formatPrice, region } = useRegion();

  return (
    <Link to={`/accessories/${product.id}`} className="no-underline">
      <div
        className="bg-card rounded-lg overflow-hidden cursor-pointer border border-border transition-all duration-300 hover:-translate-y-1 hover:shadow-lg relative"
        style={{ opacity: oos ? 0.85 : 1 }}
      >
        {discount && !oos && (
          <div
            style={{
              position: "absolute", top: 8, right: 8, zIndex: 10,
              background: "hsl(var(--foreground))", color: "hsl(var(--background))",
              fontFamily: "Georgia, serif", fontWeight: 900, fontSize: "0.7rem",
              padding: "4px 10px", borderRadius: "2rem",
            }}
          >
            -{discount}%
          </div>
        )}
        {oos && (
          <div
            style={{
              position: "absolute", top: 8, left: 8, zIndex: 10,
              background: "hsl(0 84.2% 60.2%)", color: "#fff",
              fontFamily: "Georgia, 'Times New Roman', serif",
              fontWeight: 900, fontSize: "0.62rem", letterSpacing: "0.15em",
              textTransform: "uppercase", padding: "4px 10px", borderRadius: "2rem",
            }}
          >
            Out of Stock
          </div>
        )}
        {!oos && isLowStock(product) && (
          <div
            style={{
              position: "absolute", top: 8, right: 8, zIndex: 10,
              background: "#FEF08A", color: "#854D0E",
              fontFamily: "Georgia, 'Times New Roman', serif",
              fontWeight: 700, fontSize: "11px", padding: "3px 10px",
              borderRadius: "999px", boxShadow: "0 1px 4px rgba(0,0,0,0.10)",
            }}
          >
            Few items left
          </div>
        )}
        <div
          className="bg-solea-warm flex items-center justify-center overflow-hidden"
          style={{ height: imgHeight, transition: "height 0.3s ease" }}
        >
          <img
            src={product.image || product.images?.[0] || ""}
            alt={product.name}
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).style.display = "none";
              const p = (e.currentTarget as HTMLImageElement).parentElement;
              if (p) p.innerHTML = '<span style="font-size:2rem">✨</span>';
            }}
          />
        </div>
        <div className="p-3">
          <p className="text-foreground font-serif font-bold text-base mb-0.5">{product.name}</p>
          {salePrice ? (
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <p className="font-serif text-sm" style={{ textDecoration: "line-through", opacity: 0.5 }}>
                {formatPrice(product.price, product.price_gbp)}
              </p>
              <p className="text-foreground font-serif text-sm font-bold">
                {region === "UK"
                  ? `£${Number(salePriceGbp ?? product.price_gbp ?? 0).toLocaleString("en-GB")}`
                  : `Rs. ${Number(salePrice).toLocaleString()}`}
              </p>
            </div>
          ) : (
            <p className="text-foreground font-serif font-bold text-sm">
              {formatPrice(product.price, product.price_gbp)}
            </p>
          )}
          {oos && (
            <button
              disabled
              style={{
                marginTop: "0.5rem", width: "100%",
                background: "hsl(var(--muted))", color: "hsl(var(--muted-foreground))",
                border: "none", borderRadius: "2rem", padding: "6px 0",
                fontFamily: "Georgia, 'Times New Roman', serif",
                fontWeight: 700, fontSize: "0.65rem", letterSpacing: "0.15em",
                textTransform: "uppercase", cursor: "not-allowed", opacity: 0.7,
              }}
            >
              Out of Stock
            </button>
          )}
        </div>
      </div>
    </Link>
  );
};

const Accessories = () => {
  const { data: dbProducts = [], isLoading } = useProducts();
  const { data: saleData = [] }              = useSaleProducts();

  const salePriceMap = Object.fromEntries(
    (saleData as any[]).map((s: any) => [
      s.product_id,
      { sale_price: s.sale_price, sale_price_gbp: s.sale_price_gbp },
    ])
  );

  // ── Only show products from the Accessories category in Supabase ──
  const accessories = (dbProducts as any[]).filter((p: any) => p.category === "Accessories");

  const initialViewMode = (): ViewMode =>
    typeof window !== "undefined" && window.innerWidth < 768 ? "double" : "triple";
  const [viewMode, setViewMode]   = useState<ViewMode>(initialViewMode);
  const userChangedView           = useRef(false);

  const handleViewModeChange = (mode: ViewMode) => {
    userChangedView.current = true;
    setViewMode(mode);
  };

  useEffect(() => {
    const update = () => {
      if (userChangedView.current) return;
      setViewMode(window.innerWidth < 768 ? "double" : "triple");
    };
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);

  const { sortBy, filters, sorted, filtered, maxPrice, hasFiltersApplied, setSortBy, setFilters } =
    useFilterSort(accessories, false);

  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="py-8 px-8 text-center">
        <h1 className="text-foreground font-serif text-4xl font-black max-w-[300px] mx-auto">
          Accessories
        </h1>
      </div>
      <div className="px-6 pb-16 max-w-[1100px] mx-auto">
        {!isLoading && accessories.length > 0 && (
          <FilterSortBar
            products={accessories}
            filteredCount={filtered.length}
            sortBy={sortBy}
            filters={filters}
            maxPrice={maxPrice}
            onSortChange={setSortBy}
            onFiltersApply={setFilters}
            hasFiltersApplied={hasFiltersApplied}
            showSizeFilter={false}
            viewMode={viewMode}
            onViewModeChange={handleViewModeChange}
          />
        )}

        {isLoading ? (
          /* Loading skeleton */
          <div style={getGridStyle(viewMode)}>
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-card rounded-lg overflow-hidden border border-border animate-pulse">
                <div className="h-[340px] bg-secondary/50" />
                <div className="p-3 space-y-2">
                  <div className="h-3 bg-secondary/50 rounded w-3/4" />
                  <div className="h-3 bg-secondary/50 rounded w-1/3" />
                </div>
              </div>
            ))}
          </div>
        ) : sorted.length > 0 ? (
          <div style={getGridStyle(viewMode)}>
            {sorted.map((product: any) => (
              <ProductCard
                key={product.id}
                product={product}
                viewMode={viewMode}
                salePrice={salePriceMap[product.id]?.sale_price}
                salePriceGbp={salePriceMap[product.id]?.sale_price_gbp}
              />
            ))}
          </div>
        ) : (
          <div style={{ minHeight: "30vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <p style={{ fontFamily: "Georgia, 'Times New Roman', serif", fontSize: "0.9rem", color: "hsl(var(--muted-foreground))" }}>
              {hasFiltersApplied ? "No products match your filters." : "No accessories available right now."}
            </p>
          </div>
        )}
      </div>
      <Footer />
    </main>
  );
};

export default Accessories;