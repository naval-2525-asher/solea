import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCart } from "@/context/CartContext";
import { toast } from "@/hooks/use-toast";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useRegion } from "@/context/RegionContext";
import { getAccessoryVariantStock, getProductTotalStock, LOW_STOCK_THRESHOLD } from "@/lib/inventory";
import { useSaleProducts } from "@/hooks/useAdminData";

const Lightbox = ({ src, onClose }: { src: string; onClose: () => void }) => (
  <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 9999, backgroundColor: "rgba(0,0,0,0.85)", display: "flex", alignItems: "center", justifyContent: "center" }}>
    <div onClick={(e) => e.stopPropagation()} style={{ position: "relative", maxWidth: "92vw", maxHeight: "92vh" }}>
      <button onClick={onClose} style={{ position: "absolute", top: -14, right: -14, width: 32, height: 32, borderRadius: "50%", background: "#8B1A2F", color: "white", border: "none", cursor: "pointer", fontWeight: "bold", fontSize: 16, display: "flex", alignItems: "center", justifyContent: "center", zIndex: 10 }}>✕</button>
      <img src={src} alt="Full size" style={{ maxWidth: "92vw", maxHeight: "92vh", borderRadius: 12, objectFit: "contain", display: "block" }} />
    </div>
  </div>
);

const QuantityStepper = ({ value, onChange, max }: { value: number; onChange: (v: number) => void; max?: number }) => (
  <div className="flex items-center gap-3 border-2 border-border rounded-full px-4 py-2 w-fit">
    <button onClick={() => onChange(Math.max(1, value - 1))} className="bg-transparent border-none cursor-pointer text-foreground font-serif text-lg font-bold w-5 h-5 flex items-center justify-center">−</button>
    <span className="font-serif text-sm font-bold text-foreground w-4 text-center">{value}</span>
    <button
      onClick={() => { if (max === undefined || value < max) onChange(value + 1); }}
      disabled={max !== undefined && value >= max}
      style={{ opacity: max !== undefined && value >= max ? 0.4 : 1, cursor: max !== undefined && value >= max ? "not-allowed" : "pointer" }}
      className="bg-transparent border-none text-foreground font-serif text-lg font-bold w-5 h-5 flex items-center justify-center">+</button>
  </div>
);

const AccessoryDetail = () => {
  const { id } = useParams();

  const { data: dbProduct, isLoading } = useQuery({
    queryKey: ["product", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("products").select("*").eq("id", id).single();
      if (error) return null;
      return data;
    },
    enabled: !!id,
  });

  const rawProduct = dbProduct;

  const { addToCart, items: cartItems } = useCart();
  const { region, formatPrice } = useRegion();
  const { data: saleItems = [] } = useSaleProducts();

  // Find if this product is on sale
  const saleEntry = (saleItems as any[]).find((s: any) => String(s.product_id) === String(id));
  const activeSalePrice: number | null = saleEntry ? Number(saleEntry.sale_price) : null;
  const activeSalePriceGbp: number | null = saleEntry?.sale_price_gbp ? Number(saleEntry.sale_price_gbp) : null;
  const [selectedVariant, setSelectedVariant] = useState<string | null>(null);
  const [selectedMulti, setSelectedMulti] = useState<string[]>([]);
  const [qty, setQty] = useState(1);
  const [imgIndex, setImgIndex] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  // validation
  const [shakeVariant, setShakeVariant] = useState(false);
  const [variantError, setVariantError] = useState(false);

  useEffect(() => {
    setQty(1);
  }, [selectedVariant, selectedMulti.length]);

  if (isLoading) {
    return (
      <main className="bg-background min-h-screen">
        <Navbar />
        <div className="max-w-[1000px] mx-auto mt-10 px-10 grid grid-cols-1 md:grid-cols-2 gap-16 pb-20">
          <div className="rounded-[1.5rem] bg-secondary/30 aspect-[3/4] animate-pulse" />
          <div className="pt-4 space-y-4">
            <div className="h-8 bg-secondary/30 rounded animate-pulse w-3/4" />
            <div className="h-6 bg-secondary/30 rounded animate-pulse w-1/3" />
          </div>
        </div>
      </main>
    );
  }

  if (!rawProduct) {
    return (
      <main className="bg-background min-h-screen flex items-center justify-center">
        <p className="text-foreground font-serif text-xl">Product not found.</p>
      </main>
    );
  }

  const product = {
    id: rawProduct.id,
    name: rawProduct.name,
    price: rawProduct.price,
    image: rawProduct.image || "",
    images: (() => {
      if (dbProduct) {
        const imgs = dbProduct.images as string[] | null;
        if (imgs && imgs.length > 0) return imgs;
        return dbProduct.image ? [dbProduct.image] : [];
      }
      return (rawProduct as any).image ? [(rawProduct as any).image] : [];
    })(),
    description: (rawProduct as any).description || "",
    variants: (() => {
      if (dbProduct) {
        const v = dbProduct.variants as any;
        if (Array.isArray(v)) return v;
        return [];
      }
      return (rawProduct as any).variants || [];
    })(),
  };

  const allImages = product.images;
  const hasVariants = product.variants.length > 0;

  const variantGroups: Record<string, { name: string; price_diff: number }[]> = {};
  product.variants.forEach((v: any) => {
    if (!variantGroups[v.label]) variantGroups[v.label] = [];
    variantGroups[v.label].push({ name: v.name, price_diff: v.price_diff || 0 });
  });
  const groupKeys = Object.keys(variantGroups);
  const isMultiSelect = product.variants.length > 4;

  const toggleMulti = (v: string) => {
    setSelectedMulti((prev) => prev.includes(v) ? prev.filter((x) => x !== v) : [...prev, v]);
    setVariantError(false);
  };

  const basePrice = product.price;
  const selectedVariantObj = product.variants.find((v: any) => v.name === selectedVariant);
  const singleTotal = (basePrice + (selectedVariantObj?.price_diff || 0)) * qty;
  const multiTotal = isMultiSelect
    ? selectedMulti.reduce((sum: number, name: string) => {
        const v = product.variants.find((vv: any) => vv.name === name);
        return sum + basePrice + (v?.price_diff || 0);
      }, 0) * qty
    : 0;

  const productIdForCart = (rawProduct as any)?.id ?? (typeof product.id === "number" ? product.id : 9001);

  const inCartQty = (variantName: string): number =>
    cartItems
      .filter((i) => i.productId === productIdForCart && i.style === "accessory" && i.size === variantName)
      .reduce((sum, i) => sum + i.quantity, 0);

  // Per-variant stock (e.g. colour/style), isolated per option — falls back
  // to the flat total when this accessory has no variant-level tracking.
  const getVariantStock = (variantName: string): number => getAccessoryVariantStock(rawProduct, variantName);
  const remainingForVariant = (variantName: string): number => {
    const raw = getVariantStock(variantName);
    return raw === Infinity ? Infinity : Math.max(0, raw - inCartQty(variantName));
  };

  const totalRemaining = (() => {
    const raw = getProductTotalStock(rawProduct);
    return raw === Infinity ? Infinity : Math.max(0, raw - inCartQty("One Size"));
  })();

  // What's actually selectable right now, for low-stock / OOS messaging
  const selectionRemaining = isMultiSelect
    ? (selectedMulti.length > 0 ? Math.min(...selectedMulti.map(remainingForVariant)) : Infinity)
    : hasVariants
      ? (selectedVariant ? remainingForVariant(selectedVariant) : Infinity)
      : totalRemaining;

  const allVariantsOOS = hasVariants && groupKeys.length > 0 &&
    Object.values(variantGroups).flat().every((v) => getVariantStock(v.name) <= 0);

  const isLowStock = selectionRemaining !== Infinity && selectionRemaining > 0 && selectionRemaining <= LOW_STOCK_THRESHOLD;
  const isOOS =
    (rawProduct as any).stock_status === "out_of_stock" || (rawProduct as any).stock_status === "Out of Stock" ||
    allVariantsOOS ||
    (selectionRemaining !== Infinity && selectionRemaining <= 0) ||
    (!hasVariants && totalRemaining !== Infinity && totalRemaining <= 0);

  const triggerShake = () => {
    setShakeVariant(true);
    setTimeout(() => setShakeVariant(false), 600);
  };

  const handleAdd = () => {
    if (isMultiSelect) {
      if (selectedMulti.length === 0) {
        setVariantError(true);
        triggerShake();
        return;
      }
      const oosPicked = selectedMulti.filter((v) => remainingForVariant(v) <= 0);
      if (oosPicked.length > 0) {
        toast({ title: `${oosPicked.join(", ")} ${oosPicked.length > 1 ? "are" : "is"} out of stock`, variant: "destructive" });
        return;
      }
      const shortQty = selectedMulti.find((v) => remainingForVariant(v) < qty);
      if (shortQty) {
        toast({ title: `Only ${remainingForVariant(shortQty)} of "${shortQty}" available`, variant: "destructive" });
        return;
      }
      selectedMulti.forEach((variantName) => {
        const variantPriceDiff = product.variants.find((v: any) => v.name === variantName)?.price_diff || 0;
        // Use sale price if available (sale price overrides the base; variant diff still applies on top)
        const effectiveBase = activeSalePrice !== null
          ? (region === "UK" && activeSalePriceGbp ? activeSalePriceGbp : activeSalePrice)
          : (region === "UK" && (dbProduct as any)?.price_gbp ? Number((dbProduct as any).price_gbp) : basePrice);
        for (let i = 0; i < qty; i++) {
          addToCart({
            productId: productIdForCart,
            name: product.name,
            image: allImages[0] || product.image,
            price: effectiveBase + variantPriceDiff,
            size: variantName,
            style: "accessory",
            customisation: { Style: variantName },
          });
        }
      });
      toast({ title: `${selectedMulti.length * qty} item(s) added to cart!` });
    } else if (hasVariants) {
      if (!selectedVariant) {
        setVariantError(true);
        triggerShake();
        return;
      }
      const remaining = remainingForVariant(selectedVariant);
      if (remaining <= 0) {
        toast({ title: `${selectedVariant} is out of stock`, variant: "destructive" });
        return;
      }
      if (qty > remaining) {
        toast({ title: `Only ${remaining} of "${selectedVariant}" available`, variant: "destructive" });
        return;
      }
      const variantPriceDiff = selectedVariantObj?.price_diff || 0;
      const effectiveBaseForVariant = activeSalePrice !== null
        ? (region === "UK" && activeSalePriceGbp ? activeSalePriceGbp : activeSalePrice)
        : (region === "UK" && (dbProduct as any)?.price_gbp ? Number((dbProduct as any).price_gbp) : basePrice);
      for (let i = 0; i < qty; i++) {
        addToCart({
          productId: productIdForCart,
          name: product.name,
          image: allImages[0] || product.image,
          price: effectiveBaseForVariant + variantPriceDiff,
          size: selectedVariant,
          style: "accessory",
          customisation: { Style: selectedVariant },
        });
      }
      toast({ title: `${product.name} (${selectedVariant}) added to cart!` });
    } else {
      if (totalRemaining !== Infinity && totalRemaining <= 0) {
        toast({ title: `${product.name} is out of stock`, variant: "destructive" });
        return;
      }
      if (totalRemaining !== Infinity && qty > totalRemaining) {
        toast({ title: `Only ${totalRemaining} available`, variant: "destructive" });
        return;
      }
      const effectiveBaseNoVariant = activeSalePrice !== null
        ? (region === "UK" && activeSalePriceGbp ? activeSalePriceGbp : activeSalePrice)
        : (region === "UK" && (dbProduct as any)?.price_gbp ? Number((dbProduct as any).price_gbp) : basePrice);
      for (let i = 0; i < qty; i++) {
        addToCart({
          productId: productIdForCart,
          name: product.name,
          image: allImages[0] || product.image,
          price: effectiveBaseNoVariant,
          size: "One Size",
          style: "accessory",
        });
      }
      toast({ title: `${product.name} added to cart!` });
    }
  };

  return (
    <main className="bg-background min-h-screen">
      <style>{`
        @keyframes shakeField {
          0%,100% { transform: translateX(0); }
          15%      { transform: translateX(-5px); }
          30%      { transform: translateX(5px); }
          45%      { transform: translateX(-4px); }
          60%      { transform: translateX(4px); }
          75%      { transform: translateX(-2px); }
          90%      { transform: translateX(2px); }
        }
        .shake-field { animation: shakeField 0.55s ease; }
      `}</style>

      <Navbar />

      <div className="px-10 pt-6">
        <Link to="/accessories" className="text-foreground font-serif text-sm no-underline flex items-center gap-1 opacity-70 hover:opacity-100 transition-opacity">
          ← Back
        </Link>
      </div>

      <div className="max-w-[1000px] mx-auto mt-10 px-10 grid grid-cols-1 md:grid-cols-2 gap-16 items-start pb-20">

        {/* Image viewer */}
        <div>
          <div className="rounded-[1.5rem] overflow-hidden bg-secondary aspect-[3/4] relative cursor-zoom-in"
            onClick={() => allImages.length > 0 && setLightboxOpen(true)}>
            {allImages.length > 0 ? (
              <img src={allImages[imgIndex]} alt={product.name} className="w-full h-full object-cover block"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).style.display = "none";
                  const p = (e.currentTarget as HTMLImageElement).parentElement;
                  if (p) p.innerHTML = '<div style="height:100%;display:flex;align-items:center;justify-content:center;font-size:4rem">🌶️</div>';
                }} />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-4xl">🌶️</div>
            )}

            {/* Low stock badge */}
            {isLowStock && !isOOS && (
              <div style={{ position: "absolute", top: 10, right: 10, zIndex: 10, background: "#FEF08A", color: "#854D0E", fontFamily: "Georgia, 'Times New Roman', serif", fontSize: "11px", fontWeight: 700, padding: "3px 10px", borderRadius: "999px", boxShadow: "0 1px 6px rgba(0,0,0,0.10)" }}>
                Few items left
              </div>
            )}

            {allImages.length > 1 && (
              <>
                <button onClick={(e) => { e.stopPropagation(); setImgIndex((i) => (i - 1 + allImages.length) % allImages.length); }}
                  className="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/80 backdrop-blur-sm border-none flex items-center justify-center cursor-pointer shadow-md hover:bg-white transition-colors">
                  <ChevronLeft size={18} className="text-foreground" />
                </button>
                <button onClick={(e) => { e.stopPropagation(); setImgIndex((i) => (i + 1) % allImages.length); }}
                  className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/80 backdrop-blur-sm border-none flex items-center justify-center cursor-pointer shadow-md hover:bg-white transition-colors">
                  <ChevronRight size={18} className="text-foreground" />
                </button>
                <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
                  {allImages.map((_, i) => (
                    <button key={i} onClick={(e) => { e.stopPropagation(); setImgIndex(i); }}
                      className="border-none cursor-pointer rounded-full transition-all"
                      style={{ width: i === imgIndex ? 20 : 8, height: 8, backgroundColor: i === imgIndex ? "hsl(var(--primary))" : "rgba(255,255,255,0.7)" }} />
                  ))}
                </div>
              </>
            )}
          </div>

          {allImages.length > 1 && (
            <div className="flex gap-2 mt-3 overflow-x-auto pb-1">
              {allImages.map((src: string, i: number) => (
                <button key={i} onClick={() => setImgIndex(i)}
                  className="flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 transition-all cursor-pointer"
                  style={{ borderColor: i === imgIndex ? "hsl(var(--primary))" : "hsl(var(--border))" }}>
                  <img src={src} alt={`view ${i + 1}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Product info */}
        <div className="pt-4">
          <h1 className="text-foreground font-serif text-4xl font-black mb-2">{product.name}</h1>

          {/* Price */}
          {activeSalePrice !== null ? (
            <div className="mb-8">
              {/* Sale price display */}
              <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                <p className="font-serif text-lg" style={{ textDecoration: "line-through", opacity: 0.5 }}>
                  {formatPrice(basePrice, (dbProduct as any)?.price_gbp)}
                </p>
                <p className="text-foreground font-serif text-2xl font-bold" style={{ color: "#dc2626" }}>
                  {region === "UK"
                    ? activeSalePriceGbp
                      ? `£${Number(activeSalePriceGbp).toLocaleString("en-GB")}`
                      : `£${Number((dbProduct as any)?.price_gbp ?? 0).toLocaleString("en-GB")}`
                    : `Rs. ${Number(activeSalePrice).toLocaleString()}`}
                </p>
                <span style={{
                  background: "#dc2626", color: "#fff",
                  fontFamily: "Georgia, serif", fontWeight: 900, fontSize: "0.7rem",
                  padding: "3px 10px", borderRadius: "2rem", letterSpacing: "0.05em",
                }}>
                  -{Math.round(((basePrice - activeSalePrice) / basePrice) * 100)}%
                </span>
              </div>
            </div>
          ) : isMultiSelect && selectedMulti.length > 0 ? (
            <>
              <p className="text-foreground font-serif text-lg font-bold mb-1">{formatPrice(basePrice, (dbProduct as any)?.price_gbp)} each</p>
              <p className="text-foreground font-serif text-2xl font-bold mb-8">
                Total: {region === "UK" ? `£${((dbProduct as any)?.price_gbp ?? 0 * selectedMulti.length * qty).toLocaleString("en-GB")}` : `Rs. ${multiTotal.toLocaleString()}`}
                <span className="text-sm font-normal opacity-60 ml-2">({selectedMulti.length} × {qty})</span>
              </p>
            </>
          ) : (
            <p className="text-foreground font-serif text-2xl font-bold mb-8">
              {formatPrice(isMultiSelect ? basePrice : singleTotal / qty, (dbProduct as any)?.price_gbp)}
              {isMultiSelect && <span className="text-sm font-normal opacity-60 ml-2">each</span>}
            </p>
          )}

          {/* Variants grouped by label */}
          {hasVariants && groupKeys.map((label) => (
            <div key={label} className="mb-6">
              <p className="text-foreground font-serif text-sm font-bold tracking-wider mb-3">
                {label}
                <span style={{ color: "#8B1A2F", marginLeft: 2 }}>*</span>
                {isMultiSelect && <span className="font-normal opacity-50 text-xs ml-2">(select multiple)</span>}
              </p>
              <div
                className={shakeVariant ? "shake-field" : ""}
                style={{
                  display: "flex", gap: "0.5rem", flexWrap: "wrap",
                  padding: "8px 10px", borderRadius: "0.85rem",
                  border: variantError ? "1.5px solid #8B1A2F" : "1.5px solid transparent",
                  background: variantError ? "rgba(139,26,47,0.04)" : "transparent",
                  transition: "border-color 0.2s, background 0.2s",
                }}
              >
                {variantGroups[label].map((v) => {
                  const isActive = isMultiSelect ? selectedMulti.includes(v.name) : selectedVariant === v.name;
                  const vStock = getVariantStock(v.name);
                  const vOut = vStock !== Infinity && vStock <= 0;
                  const vLow = vStock !== Infinity && vStock > 0 && vStock <= LOW_STOCK_THRESHOLD;
                  return (
                    <div key={v.name} className="flex flex-col items-center gap-1">
                      <button
                        onClick={() => {
                          if (vOut) return;
                          isMultiSelect ? toggleMulti(v.name) : setSelectedVariant(v.name);
                          setVariantError(false);
                        }}
                        disabled={vOut}
                        className="px-5 py-2 rounded-full font-serif text-sm font-bold transition-all duration-200 border-2"
                        style={{
                          cursor: vOut ? "not-allowed" : "pointer",
                          borderColor: isActive && !vOut ? "hsl(var(--primary))" : "hsl(var(--border))",
                          backgroundColor: isActive && !vOut ? "hsl(var(--primary))" : "transparent",
                          color: vOut ? "hsl(var(--muted-foreground))" : isActive ? "hsl(var(--primary-foreground))" : "hsl(var(--foreground))",
                          opacity: vOut ? 0.45 : 1,
                          textDecoration: vOut ? "line-through" : "none",
                        }}>
                        {v.name}{v.price_diff > 0 ? ` +${v.price_diff}` : v.price_diff < 0 ? ` ${v.price_diff}` : ""}
                      </button>
                      {vLow && (
                        <span style={{ fontFamily: "Georgia, serif", fontSize: "0.62rem", fontWeight: 700, color: "#B45309" }}>
                          {vStock} left
                        </span>
                      )}
                      {vOut && (
                        <span style={{ fontFamily: "Georgia, serif", fontSize: "0.62rem", fontWeight: 700, color: "hsl(var(--muted-foreground))" }}>
                          Sold out
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
              {variantError && (
                <p style={{ fontFamily: "Georgia, 'Times New Roman', serif", fontSize: "0.73rem", color: "#8B1A2F", marginTop: "0.35rem", marginLeft: "0.5rem" }}>
                  Please select {isMultiSelect ? "at least one option" : `a ${label.toLowerCase()}`} to continue
                </p>
              )}
            </div>
          ))}

          {/* Stock status */}
          {isLowStock && !isOOS && (
            <div style={{ background: "#fef3c7", border: "1px solid #fde68a", borderRadius: 10, padding: "8px 14px", marginBottom: 12 }}>
              <p style={{ fontFamily: "Georgia, serif", fontSize: "0.78rem", fontWeight: 700, color: "#92400e", margin: 0 }}>
                ⚠ Only {selectionRemaining} left — order soon!
              </p>
            </div>
          )}

          {/* Quantity */}
          <p className="text-foreground font-serif text-sm font-bold tracking-wider mb-3">Quantity</p>
          <div className="mb-10">
            <QuantityStepper value={qty} onChange={setQty} max={selectionRemaining === Infinity ? undefined : selectionRemaining} />
          </div>

          {/* Add to cart */}
          {isOOS ? (
            <button disabled className="w-full border-none rounded-full py-4 font-serif font-extrabold text-sm tracking-[0.2em] uppercase"
              style={{ background: "hsl(var(--muted))", color: "hsl(var(--muted-foreground))", cursor: "not-allowed", opacity: 0.65 }}>
              Out of Stock
            </button>
          ) : (
            <button onClick={handleAdd}
              className="w-full bg-primary text-primary-foreground border-none rounded-full py-4 font-serif font-extrabold text-sm tracking-[0.2em] uppercase cursor-pointer transition-transform duration-200 hover:scale-[1.02]">
              Add to Cart
            </button>
          )}

          {/* Description */}
          {product.description && (
            <div className="border-t border-border mt-6">
              <p className="text-foreground font-serif text-sm leading-relaxed opacity-75 pt-4">{product.description}</p>
            </div>
          )}
        </div>
      </div>

      {lightboxOpen && allImages.length > 0 && (
        <Lightbox src={allImages[imgIndex]} onClose={() => setLightboxOpen(false)} />
      )}

      <Footer />
    </main>
  );
};

export default AccessoryDetail;